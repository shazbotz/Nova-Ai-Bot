import TelegramBot from "node-telegram-bot-api";
import { config } from "../config";
import { getOrCreateUser, clearUserMemory, getUserStats, setUserPreference } from "../memory/userMemory";
import { checkCredits, addCredits, assignPlan } from "../memory/credits";
import { getProviderStatus } from "../ai/router";
import { formatFileSize } from "../files/processor";
import { logger } from "../utils/logger";
import { User, Plan } from "../memory/models";

export function registerCommands(bot: TelegramBot): void {
  bot.setMyCommands([
    { command: "start", description: "Start the bot and get a welcome message" },
    { command: "help", description: "Show all available commands" },
    { command: "clear", description: "Clear your conversation memory" },
    { command: "stats", description: "View your usage statistics and credits" },
    { command: "plan", description: "View your current plan and quota" },
    { command: "model", description: "Set your preferred AI model" },
    { command: "status", description: "Check AI provider status" },
    { command: "prompt", description: "Set a custom system prompt" },
    { command: "about", description: "About this bot" },
  ]);

  // ── /start ────────────────────────────────────────────────────────────────
  bot.onText(/\/start/, async (msg) => {
    const { id, username, first_name, last_name } = msg.from!;
    const user = await getOrCreateUser(id, { username, firstName: first_name, lastName: last_name });
    const name = first_name || username || "there";
    const credit = await checkCredits(id);
    bot.sendMessage(
      msg.chat.id,
      `👋 Hello, *${name}*! Welcome to the AI Assistant Bot.\n\n` +
        `I'm powered by multiple AI models with automatic fallback.\n\n` +
        `*What I can do:*\n` +
        `• 💬 Answer questions and chat\n` +
        `• 💻 Help with coding\n` +
        `• 📄 Analyze files (PDF, DOCX, TXT, code files)\n` +
        `• 🧠 Remember our conversations\n` +
        `• 🔄 Switch AI models automatically\n\n` +
        `📋 *Your Plan:* ${credit.planName}\n` +
        `💬 *Credits:* ${credit.isUnlimited ? "Unlimited" : `${credit.creditsRemaining}/${credit.creditsTotal} messages`}\n\n` +
        `Use /help to see all commands.`,
      { parse_mode: "Markdown" }
    );
  });

  // ── /help ─────────────────────────────────────────────────────────────────
  bot.onText(/\/help/, async (msg) => {
    const user = await User.findOne({ telegramId: msg.from!.id });
    const isAdmin = user?.isAdmin || msg.from!.id === config.telegram.adminId;

    let helpText =
      `*AI Assistant Bot - Commands*\n\n` +
      `*General:*\n` +
      `/start - Welcome message\n` +
      `/help - This help message\n` +
      `/about - About this bot\n\n` +
      `*Usage & Plan:*\n` +
      `/stats - Your usage statistics\n` +
      `/plan - Current plan & credits\n` +
      `/clear - Clear conversation history\n\n` +
      `*Preferences:*\n` +
      `/model - Set preferred AI model\n` +
      `/prompt [text] - Set custom system prompt\n\n` +
      `*AI Status:*\n` +
      `/status - Check AI provider status\n\n` +
      `*Files:*\n` +
      `📎 Send any PDF, DOCX, TXT, or code file!\n`;

    if (isAdmin) {
      helpText +=
        `\n*Admin Commands:*\n` +
        `/admin - Admin panel info\n` +
        `/broadcast [msg] - Broadcast to all users\n` +
        `/addcredits [user_id] [amount] - Add credits\n` +
        `/setplan [user_id] [plan_name] - Assign plan\n` +
        `/block [user_id] - Block a user\n` +
        `/unblock [user_id] - Unblock a user\n`;
    }

    bot.sendMessage(msg.chat.id, helpText, { parse_mode: "Markdown" });
  });

  // ── /plan ─────────────────────────────────────────────────────────────────
  bot.onText(/\/plan/, async (msg) => {
    const userId = msg.from!.id;
    const user = await User.findOne({ telegramId: userId });
    const credit = await checkCredits(userId);

    if (!user) return;

    const sub = user.subscription;
    const used = sub.creditsTotal - sub.creditsRemaining;
    const pct = sub.creditsTotal > 0 && sub.creditsTotal < 999999
      ? Math.round((used / sub.creditsTotal) * 100)
      : 0;
    const bar = buildProgressBar(pct);
    const resetDate = new Date(sub.periodEnd).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

    bot.sendMessage(
      msg.chat.id,
      `📋 *Your Subscription Plan*\n\n` +
        `🏷️ Plan: *${sub.planName}*\n` +
        `💬 Messages: ${credit.isUnlimited ? "Unlimited ♾️" : `${sub.creditsRemaining} remaining`}\n` +
        `${credit.isUnlimited ? "" : `${bar} ${pct}% used\n`}` +
        `📅 Resets: ${resetDate}\n\n` +
        `_Contact the admin to upgrade your plan._`,
      { parse_mode: "Markdown" }
    );
  });

  // ── /stats ────────────────────────────────────────────────────────────────
  bot.onText(/\/stats/, async (msg) => {
    const userId = msg.from!.id;
    const stats = await getUserStats(userId);
    const credit = await checkCredits(userId);

    bot.sendMessage(
      msg.chat.id,
      `📊 *Your Statistics*\n\n` +
        `📋 Plan: *${credit.planName}*\n` +
        `💬 Credits Left: *${credit.isUnlimited ? "Unlimited ♾️" : credit.creditsRemaining}*\n\n` +
        `📨 Total Messages: ${stats.totalMessages}\n` +
        `🧠 Messages in Memory: ${stats.messagesInMemory}\n` +
        `📄 Files Processed: ${stats.filesProcessed}\n` +
        `🤖 Preferred Model: ${stats.preferredModel}\n` +
        `📅 Member Since: ${stats.joinedAt ? new Date(stats.joinedAt).toLocaleDateString() : "N/A"}\n` +
        `⏰ Last Active: ${stats.lastActiveAt ? new Date(stats.lastActiveAt).toLocaleString() : "N/A"}`,
      { parse_mode: "Markdown" }
    );
  });

  // ── /clear ────────────────────────────────────────────────────────────────
  bot.onText(/\/clear/, async (msg) => {
    await clearUserMemory(msg.from!.id);
    bot.sendMessage(msg.chat.id, "🗑️ Conversation memory cleared. Starting fresh!");
  });

  // ── /status ───────────────────────────────────────────────────────────────
  bot.onText(/\/status/, async (msg) => {
    const providers = await getProviderStatus();
    let text = `🤖 *AI Provider Status*\n\n`;
    for (const p of providers) {
      const icon = p.enabled ? "✅" : "❌";
      const reqs = p.stats.totalRequests;
      const errs = p.stats.totalErrors;
      const pct = reqs > 0 ? Math.round(((reqs - errs) / reqs) * 100) : 100;
      text += `${icon} *${p.name}* (Priority: ${p.priority})\n   Model: \`${p.defaultModel}\` | Success: ${pct}%\n\n`;
    }
    bot.sendMessage(msg.chat.id, text, { parse_mode: "Markdown" });
  });

  // ── /model ────────────────────────────────────────────────────────────────
  bot.onText(/\/model/, async (msg) => {
    const providers = await getProviderStatus();
    const keyboard: TelegramBot.InlineKeyboardButton[][] = [];
    for (const p of providers.filter((p) => p.enabled)) {
      for (const model of p.models) {
        keyboard.push([{ text: `${p.name}: ${model}`, callback_data: `setmodel:${p.slug}:${model}` }]);
      }
    }
    keyboard.push([{ text: "🔄 Auto (Best Available)", callback_data: "setmodel:auto:auto" }]);
    bot.sendMessage(msg.chat.id, "🤖 *Select your preferred AI model:*", {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard },
    });
  });

  // ── /prompt ───────────────────────────────────────────────────────────────
  bot.onText(/\/prompt(.*)/, async (msg, match) => {
    const promptText = match?.[1]?.trim();
    if (!promptText) {
      bot.sendMessage(msg.chat.id,
        "📝 *Set Custom System Prompt*\n\nUsage: `/prompt You are a helpful coding assistant`",
        { parse_mode: "Markdown" }
      );
      return;
    }
    await setUserPreference(msg.from!.id, "systemPrompt", promptText);
    bot.sendMessage(msg.chat.id, `✅ System prompt set!\n\n_"${promptText.slice(0, 100)}..."_`, { parse_mode: "Markdown" });
  });

  // ── /about ────────────────────────────────────────────────────────────────
  bot.onText(/\/about/, (msg) => {
    bot.sendMessage(msg.chat.id,
      `*AI Assistant Bot*\n\nMulti-provider AI with automatic failover.\n\n` +
      `*Providers:* OpenAI • Anthropic • Gemini • Groq\n` +
      `*Features:* Memory • File analysis • Subscription plans\n\n` +
      `Built with TypeScript + Node.js`,
      { parse_mode: "Markdown" }
    );
  });

  // ── Admin: /addcredits ────────────────────────────────────────────────────
  bot.onText(/\/addcredits (\d+) (\d+)/, async (msg, match) => {
    if (msg.from!.id !== config.telegram.adminId) return;
    const targetId = parseInt(match?.[1] || "0");
    const amount = parseInt(match?.[2] || "0");
    try {
      const newTotal = await addCredits(targetId, amount);
      bot.sendMessage(msg.chat.id, `✅ Added *${amount}* credits to user \`${targetId}\`.\nNew balance: *${newTotal}* credits.`, { parse_mode: "Markdown" });
      bot.sendMessage(targetId, `🎁 *${amount} credits* have been added to your account!\nYou now have *${newTotal}* messages available.`, { parse_mode: "Markdown" });
    } catch (err) {
      bot.sendMessage(msg.chat.id, `❌ Error: ${err instanceof Error ? err.message : err}`);
    }
  });

  // ── Admin: /setplan ───────────────────────────────────────────────────────
  bot.onText(/\/setplan (\d+) (.+)/, async (msg, match) => {
    if (msg.from!.id !== config.telegram.adminId) return;
    const targetId = parseInt(match?.[1] || "0");
    const planName = match?.[2]?.trim() || "";
    try {
      const plan = await Plan.findOne({ name: new RegExp(planName, "i") });
      if (!plan) { bot.sendMessage(msg.chat.id, `❌ Plan "${planName}" not found.`); return; }
      await assignPlan(targetId, String(plan._id));
      bot.sendMessage(msg.chat.id, `✅ User \`${targetId}\` assigned to *${plan.name}* plan (${plan.messagesPerMonth} msgs/month).`, { parse_mode: "Markdown" });
      bot.sendMessage(targetId,
        `🎉 Your plan has been upgraded to *${plan.name}*!\n\n💬 You now have *${plan.messagesPerMonth === 999999 ? "Unlimited" : plan.messagesPerMonth}* messages per month.\n\nUse /plan to see your details.`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    } catch (err) {
      bot.sendMessage(msg.chat.id, `❌ Error: ${err instanceof Error ? err.message : err}`);
    }
  });

  // ── Admin: /broadcast ─────────────────────────────────────────────────────
  bot.onText(/\/broadcast (.+)/, async (msg, match) => {
    if (msg.from!.id !== config.telegram.adminId) return;
    const message = match?.[1];
    if (!message) return;
    const users = await User.find({ isBlocked: false });
    let sent = 0;
    for (const user of users) {
      try {
        await bot.sendMessage(user.telegramId, `📢 *Broadcast*\n\n${message}`, { parse_mode: "Markdown" });
        sent++;
      } catch { /* user may have blocked bot */ }
    }
    bot.sendMessage(msg.chat.id, `✅ Sent to ${sent}/${users.length} users.`);
  });

  // ── Admin: /block /unblock ────────────────────────────────────────────────
  bot.onText(/\/block (\d+)/, async (msg, match) => {
    if (msg.from!.id !== config.telegram.adminId) return;
    await User.updateOne({ telegramId: parseInt(match?.[1] || "0") }, { $set: { isBlocked: true } });
    bot.sendMessage(msg.chat.id, `✅ User ${match?.[1]} blocked.`);
  });

  bot.onText(/\/unblock (\d+)/, async (msg, match) => {
    if (msg.from!.id !== config.telegram.adminId) return;
    await User.updateOne({ telegramId: parseInt(match?.[1] || "0") }, { $set: { isBlocked: false } });
    bot.sendMessage(msg.chat.id, `✅ User ${match?.[1]} unblocked.`);
  });

  // ── Admin: /admin ─────────────────────────────────────────────────────────
  bot.onText(/\/admin/, async (msg) => {
    if (msg.from!.id !== config.telegram.adminId) return;
    bot.sendMessage(msg.chat.id,
      `🔐 *Admin Commands*\n\n` +
      `/addcredits [user_id] [amount] - Add credits to a user\n` +
      `/setplan [user_id] [plan_name] - Assign plan (Free/Basic/Pro/Unlimited)\n` +
      `/broadcast [msg] - Send to all users\n` +
      `/block [user_id] - Block user\n` +
      `/unblock [user_id] - Unblock user\n\n` +
      `_Full admin dashboard available on the web panel._`,
      { parse_mode: "Markdown" }
    );
  });

  // ── Callback: model selection ─────────────────────────────────────────────
  bot.on("callback_query", async (query) => {
    if (!query.data?.startsWith("setmodel:")) return;
    const parts = query.data.split(":");
    const providerSlug = parts[1];
    const model = parts[2];
    const userId = query.from.id;

    if (providerSlug === "auto") {
      await setUserPreference(userId, "preferredModel", undefined);
      await setUserPreference(userId, "preferredProvider", undefined);
      bot.answerCallbackQuery(query.id, { text: "✅ Set to Auto mode" });
      bot.editMessageText("✅ Model set to *Auto* (best available)", {
        chat_id: query.message!.chat.id,
        message_id: query.message!.message_id,
        parse_mode: "Markdown",
      });
    } else {
      await setUserPreference(userId, "preferredModel", model);
      await setUserPreference(userId, "preferredProvider", providerSlug);
      bot.answerCallbackQuery(query.id, { text: `✅ Set to ${model}` });
      bot.editMessageText(`✅ Model set to \`${model}\``, {
        chat_id: query.message!.chat.id,
        message_id: query.message!.message_id,
        parse_mode: "Markdown",
      });
    }
  });

  logger.info("Bot commands registered");
}

function buildProgressBar(pct: number): string {
  const filled = Math.round(pct / 10);
  return "█".repeat(filled) + "░".repeat(10 - filled);
}
